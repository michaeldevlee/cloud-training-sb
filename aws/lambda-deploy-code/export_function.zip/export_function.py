import sys
import logging
import pymysql
import json
import os
import boto3
from datetime import datetime, timedelta
import time

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS SDK clients
s3_client = boto3.client('s3')
logs = boto3.client('logs')

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
        conn = pymysql.connect(host=rds_proxy_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")

def lambda_handler(event, context):
    query = "fields @timestamp, @message, @logStream, @log | sort @timestamp desc | limit 20"
    log_group = "/aws/lambda/export-to-s3-from-log-group"

    start_query_response = logs.start_query(
    logGroupName=log_group,
    startTime=int((datetime.today() - timedelta(hours=1)).timestamp()),
    endTime=int(datetime.now().timestamp()),
    queryString=query,
    )
    
    query_id = start_query_response['queryId']
    
    
    return start_query_response

    